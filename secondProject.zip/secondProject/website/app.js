// Create a new date instance dynamically with JS
const date= new Date();
const newDate = date.getMonth()+1+'.'+ date.getDate()+'.'+ date.getFullYear();
const baseURL = 'http://api.openweathermap.org/data/2.5/weather?zip=';
const apiKey = '&appid=797b515d5afb3393ee9be2aa446b08d4';
// Event listener to add function to existing HTML DOM element
document.getElementById('generate').addEventListener('click', Generate);
//when generate button is clicked
function Generate(){
    const zipCode= document.getElementById('zip').value;
    const feelings= document.getElementById('feelings').value;
    weatherInfo(baseURL, zipCode, apiKey)
    //get zip code from Api
    .then(function(data){
        console.log(data); 
        postData('/add', {date:newDate, temp:data.main.temp, content:feelings})
        updateUI();
       
    }
        );
    };
//function to GET web api//
const weatherInfo = async(baseURL, zipCode, apiKey) => {
    const response = await fetch(baseURL + zipCode + apiKey)
    try{
        const data = await response.json();
        return data;
    } catch(error){
        console.log("error", error)
    }
    }
//function POST data
const postData = async(url = '', data={}) => {
    console.log(data);
    const response = await fetch(url ,{
        method: 'POST',
        credentials: 'same-origin',
        headers:{
            'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
});
try{
    const newData = await response.json();
    console.log(newData);
    return newData;
} catch(error){
    console.log("error", error)
}
}
//updat UI
const updateUI= async() =>{
    const request = await fetch('/all');
    try{
       const allData = await request.json();
       document.getElementById('date').innerHTML = `Date is: ${allData[0].date}`;
       document.getElementById('temp').innerHTML = `Temperature is: ${allData[0].temp}`;
       document.getElementById('content').innerHTML = `I am: ${allData[0].content}`;
   }catch(error){
       console.log("error", error)
   };

   }